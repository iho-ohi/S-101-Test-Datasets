The following issues have been solved in the V2

General : CONRAD == 3 radar conspicuous (has radar reflector) #35 
New S-164 Test datasets have all resources merged #45 
Naming convention for datasets #49 
Producer Code Issue #51 
DataSet Iso8211 Header #52 
LightVisibilty = obscured under LightSectored #55
Dataset scales overlap #56 
 Quality of Bathymetric Data and ECDIS Performance (Management of Temporal variation) #57 

